package uns.ac.rs.prodavnica.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import uns.ac.rs.prodavnica.dto.LoginDTO;
import uns.ac.rs.prodavnica.entity.CurrentLogged;
import uns.ac.rs.prodavnica.entity.Role;
import uns.ac.rs.prodavnica.entity.User;
import uns.ac.rs.prodavnica.service.CurrentLoggedService;
import uns.ac.rs.prodavnica.service.UserService;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private CurrentLoggedService currentLoggedService;

    @GetMapping("/")
    public String welcome() {
        return "home";
    }

    @GetMapping("/user")
    public String stranica() {
        return "user";
    }


    @GetMapping("/admin-profil")
    public String deda( Model model) {
        CurrentLogged cr = currentLoggedService.getCurrentUser();
        if (cr != null) {

            User u = userService.findOneByUsername(cr.getUsername());
            if (u.getRole().equals(Role.ADMIN)) {

                model.addAttribute("user", u);

            } else {
                return "error-page";
            }

        } else {
            return "error-page";
        }
        return "admin-profil";
    }

    @GetMapping("/dostavljac-profil")
    public String dedaa( Model model) {
        CurrentLogged cr = currentLoggedService.getCurrentUser();
        if (cr != null) {

            User u = userService.findOneByUsername(cr.getUsername());
            if (u.getRole().equals(Role.DELIVER)) {

                model.addAttribute("user", u);

            } else {
                return "error-page";
            }

        } else {
            return "error-page";
        }
        return "dostavljac-profil";
    }

    @GetMapping("/kupac-profil")
    public String dedaaa( Model model) {
        CurrentLogged cr = currentLoggedService.getCurrentUser();
        if (cr != null) {

            User u = userService.findOneByUsername(cr.getUsername());
            if (u.getRole().equals(Role.BUYER)) {

                model.addAttribute("user", u);

            } else {
                return "error-page";
            }

        } else {
            return "error-page";
        }
        return "kupac-profil";
    }

    @GetMapping("/add-user")
    public String addUser(@ModelAttribute("prov") String prov,Model model) {
        boolean b = prov.equals("true"); // "true" == "true" , "false" == "true"
        model.addAttribute("user", new User());
        model.addAttribute("prov", b);
        System.out.println("h");
        return "add-user.html";
    }

    @GetMapping("/logout")
    public String logout() {
        currentLoggedService.deleteAll();
        return "redirect:/login";
    }


    @PostMapping("/save-user")
    public String saveUser(@ModelAttribute User user, BindingResult errors, Model model,RedirectAttributes rattrs)
            throws Exception {
        /*
         * trenutno setujem username da bude isto kao i first name
         * i setujem pass da bude isto kao i lastname
         * */
        user.setFirstName(user.getFirstName());
        user.setLastName(user.getLastName());
        user.setUsername(user.getUsername());
        user.setPassword(user.getPassword());
        user.setRole(user.getRole());
        user.setTelephone(user.getTelephone());
        User u = this.userService.registration(user);
        if (u == null)
        {
            rattrs.addFlashAttribute("prov","true");  //neuspesna registracija
            return "redirect:/add-user";
        }
        //System.out.println("here:" + u.getFirstName() + " " + u.getLastName());

        return "redirect:login";
    }

    @GetMapping("/login")
    public String login(Model model) {
        // logika ako je ulogovan da ne vidi ovu stranicu, ako je vec ulogovan ne moze se opet logovati
        if (currentLoggedService.getCurrentUser() != null) {
            return "error-page";
        }

        model.addAttribute("loginDTO", new LoginDTO()); //<key, value> , loginDTO je kljuc
        model.addAttribute("prov", false);

        //System.out.println("h");
        return "login.html";
    }
    
    
/*
    @GetMapping("/user")
    public String userHomePage(Model model) {
    	model.addAttribute("user", new User());
        return "user.html";
    }
*/

    @PostMapping("/provera")
    public String login(@ModelAttribute LoginDTO loginDTO, BindingResult errors, Model model){//,RedirectAttributes rattrs) {
        String username = loginDTO.getUsername();
        String password = loginDTO.getPassword();
        User user = userService.login(username, password);

        if (user != null) {
            CurrentLogged cr = new CurrentLogged(null, user.getUsername(), user.getRole());
            currentLoggedService.save(cr);
            // TODO svaki put kad se neko loguje ja snimim tog usera u current logged
            // svaki profil treba da ima log out dugme,
            // prilikom klika na ovo dugme brise se trenutno ulogovani iz baze
            // i prikaze se login stranica
            // prilikom get-a bilo koje stranice
            // npr ako je ulogovan korisnik
            // i pokusa da pozove reg ili login stranicu
            // u ove dve funkcije
            if (user.getRole().equals(Role.ADMIN)) {
                //rattrs.addFlashAttribute("user", user);

                return "redirect:/admin-profil";
            } else if (user.getRole().equals(Role.BUYER)) {
               // rattrs.addFlashAttribute("user", user);
                return "redirect:/kupac-profil";
            } else {

                System.out.println("POZVIAM AMDINA");
               // rattrs.addFlashAttribute("user", user);
                return "redirect:/dostavljac-profil";
            }
            // ovde logika da u zavisnosti od role vratim drugaciju stranicu

        }
        model.addAttribute("prov", true);
        return "login.html";
    }

    public String registration(User user) {
        userService.registration(user);

        return "redirect:/login";
    }

    @PostMapping("/changeRole")
    public String promeniRolu(@RequestParam(value = "id") int id) throws Exception {
        User user = userService.findOne((long) id);
        System.out.println(user);
        user.setRole(Role.BUYER);
        userService.update(user);
        return "redirect:/users";
    }

    @GetMapping("/users")
    public String getEmployees(Model model) {
        model.addAttribute("users", userService.findAll());
        return "users";
    }

    /*
    @GetMapping("/users/{username}")
    public String getUser(@PathVariable(name = "username") Long id, Model model) {
        model.addAttribute("user", userService.findOneByUsername(username));
        return "user";
    }


    @GetMapping("/users/{id}")
    public String getEmployee(@PathVariable(name = "id") Long id,
                              Model model) {
        model.addAttribute("user", employeeService.findOne(id));

        return "admin-profil.html";
    }
     */

}

